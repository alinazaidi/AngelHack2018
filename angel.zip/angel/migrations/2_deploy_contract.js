var UserLogin = artifacts.require("./UserLogin.sol");
module.exports = function(deployer) {
  deployer.deploy(UserLogin);

};
